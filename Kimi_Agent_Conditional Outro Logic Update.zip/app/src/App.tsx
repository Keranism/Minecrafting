import { useState, useEffect } from 'react';
import './index.css';

// Background images for each stage
const BACKGROUNDS = {
  login: 'https://digistatement.com/wp-content/uploads/2020/07/Minecraft-Famous-Title-Screen-Background-World-Seed.jpg', // Minecraft title screen
  overworld: 'https://images6.alphacoders.com/542/thumb-1920-542431.jpg', // Bright overworld landscape
  underground: 'https://static0.srcdn.com/wordpress/wp-content/uploads/2023/07/minecraft-massive-diamond-ore-chunk-in-underground-cavern-near-waterfall-and-lavafall.jpg', // Cave interior
  nether: 'https://wallpapers.com/images/hd/minecraft-nether-dimension-lavaand-red-biome-4ro2wccz7o0qchy9.jpg', // Nether dimension
  end: 'https://res.cloudinary.com/ddbybfkod/image/upload/v1710275918/blogs/Roman/how-to-defeat-the-ender-dragon/img3_oo7hlp.jpg', // The End dimension
  victory: 'https://staticg.sportskeeda.com/editor/2022/12/69181-16711100520294-1920.jpg', // End Portal/Dragon
};

// Discord logo SVG
const DiscordLogo = () => (
  <svg viewBox="0 0 127.14 96.36" fill="white">
    <path d="M107.7,8.07A105.15,105.15,0,0,0,81.47,0a72.06,72.06,0,0,0-3.36,6.83A97.68,97.68,0,0,0,49,6.83,72.37,72.37,0,0,0,45.64,0,105.89,105.89,0,0,0,19.39,8.09C2.79,32.65-1.71,56.6.54,80.21h0A105.73,105.73,0,0,0,32.71,96.36,77.7,77.7,0,0,0,39.6,85.25a68.42,68.42,0,0,1-10.85-5.78c.91-.66,1.8-1.34,2.66-2a75.57,75.57,0,0,0,64.32,0c.87.71,1.76,1.39,2.66,2a68.68,68.68,0,0,1-10.87,5.78,77,77,0,0,0,6.89,11.1A105.25,105.25,0,0,0,126.6,80.22h0C129.24,52.84,122.09,29.11,107.7,8.07ZM42.45,65.69C36.18,65.69,31,60,31,53s5-12.74,11.43-12.74S54,46,53.89,53,48.84,65.69,42.45,65.69Zm42.24,0C78.41,65.69,73.25,60,73.25,53s5-12.74,11.44-12.74S96.23,46,96.12,53,91.08,65.69,84.69,65.69Z"/>
  </svg>
);

// Types
interface Submission {
  email: string;
  interests: string[];
  pcSpecs: number;
  age: number;
  platform: string;
  timestamp: string;
}

interface FormData {
  email: string;
  interests: string[];
  pcSpecs: number;
  age: number;
  platform: string;
}

const ADMIN_EMAIL = 'jabutaha222@gmail.com';
const STORAGE_KEY = 'minecraft_questionnaire_submissions';

function App() {
  const [currentStage, setCurrentStage] = useState(0);
  const [currentBg, setCurrentBg] = useState(BACKGROUNDS.login);
  const [bgTransition, setBgTransition] = useState(false);
  const [error, setError] = useState('');
  const [showAdminModal, setShowAdminModal] = useState(false);
  const [submissions, setSubmissions] = useState<Submission[]>([]);
  
  const [formData, setFormData] = useState<FormData>({
    email: '',
    interests: [],
    pcSpecs: 8,
    age: 18,
    platform: ''
  });

  // Load submissions from localStorage on mount
  useEffect(() => {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored) {
      setSubmissions(JSON.parse(stored));
    }
  }, []);

  // Change background with transition
  const changeBackground = (newBg: string) => {
    setBgTransition(true);
    setTimeout(() => {
      setCurrentBg(newBg);
      setBgTransition(false);
    }, 400);
  };

  // Email validation regex
  const validateEmail = (email: string): boolean => {
    const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return regex.test(email);
  };

  // Check if email already submitted
  const isDuplicateEmail = (email: string): boolean => {
    if (email === ADMIN_EMAIL) return false; // Admin exempt
    return submissions.some(sub => sub.email === email);
  };

  // Save submission to localStorage
  const saveSubmission = () => {
    const newSubmission: Submission = {
      email: formData.email,
      interests: formData.interests,
      pcSpecs: formData.pcSpecs,
      age: formData.age,
      platform: formData.platform,
      timestamp: new Date().toLocaleString()
    };
    
    const updatedSubmissions = [...submissions, newSubmission];
    setSubmissions(updatedSubmissions);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updatedSubmissions));
  };

  // Handle Stage 0: Login
  const handleLogin = () => {
    setError('');
    
    if (!formData.email || !validateEmail(formData.email)) {
      setError('Please enter a valid email address!');
      return;
    }
    
    if (isDuplicateEmail(formData.email)) {
      setError('You have already completed this quest!');
      return;
    }
    
    changeBackground(BACKGROUNDS.overworld);
    setCurrentStage(1);
  };

  // Handle Stage 1: Overworld (Interests)
  const handleInterestsSubmit = () => {
    if (formData.interests.length === 0) {
      setError('Please select at least one interest!');
      return;
    }
    setError('');
    changeBackground(BACKGROUNDS.underground);
    setCurrentStage(2);
  };

  // Handle Stage 2: Underground (PC Specs)
  const handlePcSpecsSubmit = () => {
    changeBackground(BACKGROUNDS.nether);
    setCurrentStage(3);
  };

  // Handle Stage 3: Nether (Age)
  const handleAgeSubmit = () => {
    if (!formData.age || formData.age < 1 || formData.age > 120) {
      setError('Please enter a valid age!');
      return;
    }
    setError('');
    changeBackground(BACKGROUNDS.end);
    setCurrentStage(4);
  };

  // Handle Stage 4: The End (Platform)
  const handlePlatformSubmit = () => {
    if (!formData.platform) {
      setError('Please select a platform!');
      return;
    }
    setError('');
    saveSubmission();
    changeBackground(BACKGROUNDS.victory);
    setCurrentStage(5);
  };

  // Toggle interest selection
  const toggleInterest = (interest: string) => {
    setFormData(prev => ({
      ...prev,
      interests: prev.interests.includes(interest)
        ? prev.interests.filter(i => i !== interest)
        : [...prev.interests, interest]
    }));
    setError('');
  };

  // Clear all data (admin only)
  const clearAllData = () => {
    if (confirm('Are you sure you want to delete ALL submissions? This cannot be undone!')) {
      localStorage.removeItem(STORAGE_KEY);
      setSubmissions([]);
    }
  };

  // Render Stage 0: Login
  const renderLogin = () => (
    <div className="minecraft-container">
      <h1 className="stage-title">MINECRAFT QUEST</h1>
      <p className="question-text">Enter your email to begin the adventure!</p>
      
      <input
        type="email"
        className="minecraft-input"
        placeholder="your@email.com"
        value={formData.email}
        onChange={(e) => {
          setFormData(prev => ({ ...prev, email: e.target.value }));
          setError('');
        }}
        onKeyPress={(e) => e.key === 'Enter' && handleLogin()}
      />
      
      {error && <p className="minecraft-error">{error}</p>}
      
      <button 
        className="minecraft-btn minecraft-btn-primary mt-6 w-full"
        onClick={handleLogin}
      >
        START ADVENTURE
      </button>
    </div>
  );

  // Render Stage 1: Overworld (Interests)
  const renderOverworld = () => (
    <div className="minecraft-container">
      <h1 className="stage-title">THE OVERWORLD</h1>
      <p className="question-text">What are you interested in?<br/><span style={{fontSize: '0.6rem', color: '#aaa'}}>(Select all that apply)</span></p>
      
      <div className="space-y-3">
        {['Discord', 'Hytale', 'Minecraft'].map(interest => (
          <label key={interest} className="option-label">
            <input
              type="checkbox"
              className="minecraft-checkbox"
              checked={formData.interests.includes(interest)}
              onChange={() => toggleInterest(interest)}
            />
            <span>{interest}</span>
          </label>
        ))}
      </div>
      
      {error && <p className="minecraft-error">{error}</p>}
      
      <button 
        className="minecraft-btn minecraft-btn-primary mt-6 w-full"
        onClick={handleInterestsSubmit}
      >
        CONTINUE →
      </button>
    </div>
  );

  // Render Stage 2: Underground (PC Specs)
  const renderUnderground = () => (
    <div className="minecraft-container">
      <h1 className="stage-title">THE UNDERGROUND</h1>
      <p className="question-text">Rate your PC Specs</p>
      
      <div className="py-4">
        <input
          type="range"
          className="minecraft-slider"
          min="4"
          max="12"
          step="1"
          value={formData.pcSpecs}
          onChange={(e) => setFormData(prev => ({ ...prev, pcSpecs: parseInt(e.target.value) }))}
        />
        <div className="flex justify-between mt-3 text-xs" style={{color: '#aaa'}}>
          <span>Low (4GB)</span>
          <span>Mid (8GB)</span>
          <span>High (12GB+)</span>
        </div>
        <p className="text-center mt-4" style={{color: '#5D8C3A', fontSize: '0.8rem'}}>
          Selected: {formData.pcSpecs}GB RAM
        </p>
      </div>
      
      <button 
        className="minecraft-btn minecraft-btn-primary mt-6 w-full"
        onClick={handlePcSpecsSubmit}
      >
        DESCEND DEEPER →
      </button>
    </div>
  );

  // Render Stage 3: Nether (Age)
  const renderNether = () => (
    <div className="minecraft-container">
      <h1 className="stage-title">THE NETHER</h1>
      <p className="question-text">How old are you?</p>
      
      <input
        type="number"
        className="minecraft-input text-center"
        placeholder="Enter your age"
        min="1"
        max="120"
        value={formData.age || ''}
        onChange={(e) => {
          setFormData(prev => ({ ...prev, age: parseInt(e.target.value) || 0 }));
          setError('');
        }}
        onKeyPress={(e) => e.key === 'Enter' && handleAgeSubmit()}
      />
      
      {error && <p className="minecraft-error">{error}</p>}
      
      <button 
        className="minecraft-btn minecraft-btn-primary mt-6 w-full"
        onClick={handleAgeSubmit}
      >
        ENTER THE PORTAL →
      </button>
    </div>
  );

  // Render Stage 4: The End (Platform)
  const renderEnd = () => (
    <div className="minecraft-container">
      <h1 className="stage-title">THE END</h1>
      <p className="question-text">Preferred platform for a server?</p>
      
      <div className="space-y-3">
        {['Discord', 'WhatsApp', 'Instagram'].map(platform => (
          <label key={platform} className="option-label">
            <input
              type="radio"
              className="minecraft-radio"
              name="platform"
              checked={formData.platform === platform}
              onChange={() => {
                setFormData(prev => ({ ...prev, platform }));
                setError('');
              }}
            />
            <span>{platform}</span>
          </label>
        ))}
      </div>
      
      {error && <p className="minecraft-error">{error}</p>}
      
      <button 
        className="minecraft-btn minecraft-btn-primary mt-6 w-full"
        onClick={handlePlatformSubmit}
      >
        DEFEAT THE DRAGON →
      </button>
    </div>
  );

  // Render Stage 5: Victory
  const renderVictory = () => (
    <div className="minecraft-container text-center">
      <h1 className="stage-title">VICTORY!</h1>
      <p className="question-text">Join the Adventure!</p>
      
      {/* Conditional subtitle for users 18+ */}
      {formData.age >= 18 && (
        <p className="age-subtitle">
          dayum your above 18 unc how are your kids grandpa
        </p>
      )}
      
      <div className="discord-container py-6">
        <a 
          href="https://discord.gg/TbMrFNBQQ4"
          target="_blank"
          rel="noopener noreferrer"
          className="discord-logo"
        >
          <DiscordLogo />
        </a>
        <p style={{fontSize: '0.6rem', color: '#aaa'}}>
          Click the logo to join our Discord!
        </p>
      </div>
      
      {/* Admin button - only for admin email */}
      {formData.email === ADMIN_EMAIL && (
        <button 
          className="minecraft-btn minecraft-btn-admin mt-4"
          onClick={() => setShowAdminModal(true)}
        >
          ADMIN: VIEW RESULTS
        </button>
      )}
    </div>
  );

  // Render Admin Modal
  const renderAdminModal = () => (
    <div className="modal-overlay" onClick={() => setShowAdminModal(false)}>
      <div className="modal-content" onClick={(e) => e.stopPropagation()}>
        <div className="flex justify-between items-center mb-4">
          <h2 style={{color: '#FFD700', fontSize: '1rem'}}>ADMIN DASHBOARD</h2>
          <button 
            className="minecraft-btn"
            onClick={() => setShowAdminModal(false)}
          >
            CLOSE
          </button>
        </div>
        
        <p style={{color: '#aaa', fontSize: '0.6rem', marginBottom: '1rem'}}>
          Total Submissions: {submissions.length}
        </p>
        
        {submissions.length > 0 ? (
          <table className="data-table">
            <thead>
              <tr>
                <th>Email</th>
                <th>Interests</th>
                <th>PC Specs</th>
                <th>Age</th>
                <th>Platform</th>
                <th>Timestamp</th>
              </tr>
            </thead>
            <tbody>
              {submissions.map((sub, index) => (
                <tr key={index}>
                  <td>{sub.email}</td>
                  <td>{sub.interests.join(', ')}</td>
                  <td>{sub.pcSpecs}GB</td>
                  <td>{sub.age}</td>
                  <td>{sub.platform}</td>
                  <td>{sub.timestamp}</td>
                </tr>
              ))}
            </tbody>
          </table>
        ) : (
          <p style={{color: '#aaa', textAlign: 'center', padding: '2rem'}}>
            No submissions yet.
          </p>
        )}
        
        <button 
          className="minecraft-btn minecraft-btn-danger mt-6 w-full"
          onClick={clearAllData}
        >
          CLEAR ALL DATA
        </button>
      </div>
    </div>
  );

  // Render current stage
  const renderStage = () => {
    switch (currentStage) {
      case 0: return renderLogin();
      case 1: return renderOverworld();
      case 2: return renderUnderground();
      case 3: return renderNether();
      case 4: return renderEnd();
      case 5: return renderVictory();
      default: return renderLogin();
    }
  };

  return (
    <div className="min-h-screen w-full flex items-center justify-center relative">
      {/* Background layers with transition */}
      <div 
        className={`bg-layer ${bgTransition ? 'inactive' : 'active'}`}
        style={{ backgroundImage: `url(${currentBg})` }}
      />
      
      {/* Dark overlay */}
      <div className="bg-overlay" />
      
      {/* Main content */}
      <div className="relative z-10 w-full px-4 py-8">
        {renderStage()}
      </div>
      
      {/* Admin Modal */}
      {showAdminModal && renderAdminModal()}
    </div>
  );
}

export default App;
